public class MakinaMuh  extends Ogrenci{
    public MakinaMuh(String  ogrenciNo, String ad, String soyad, String girisTarihi, String fakulte, String bolum) {
        super(ogrenciNo, ad, soyad, girisTarihi, fakulte, bolum);
    }
}
