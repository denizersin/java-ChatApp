import java.util.Date;

public abstract class Ogrenci {
    String ogrenciNo;
    String ad;
    String soyad;
    String girisTarihi;
    String Fakulte;
    String Bolum;

    Ogrenci(String ogrenciNo,String ad,String soyad,String girisTarihi,String Fakultre,String Bolum){

    }
}
