public class MeatronikMuh extends Ogrenci{
    public MeatronikMuh(String  ogrenciNo, String ad, String soyad, String girisTarihi, String fakulte, String bolum) {
        super(ogrenciNo, ad, soyad, girisTarihi, fakulte, bolum);
    }
}
