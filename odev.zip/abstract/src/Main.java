public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Ogrenci ogr1=new YazilimMuh("123213","ersin","debniz","2021","hasanferdii","yazilim");
        Ogrenci ogr2=new MakinaMuh("123213","ersin","debniz","2021","hasanferdii","yazilim");

        YazilimMuh ersin=new YazilimMuh("123213","ersin","debniz","2021","hasanferdii","yazilim");
    }
}
