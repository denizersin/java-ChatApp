public class YazilimMuh extends Ogrenci{
    public YazilimMuh(String  ogrenciNo, String ad, String soyad, String girisTarihi, String fakulte, String bolum) {
        super(ogrenciNo, ad, soyad, girisTarihi, fakulte, bolum);
    }
}

